/***************************************************************************************

***************************************************************************************/



/*
*************************************************************************************
* File name: defines.h
* Function: Headerfile containing some useful global definitions
*
*************************************************************************************
*/


#ifndef _DEFINES_H_
#define _DEFINES_H_

#include <stdlib.h>  

#define M38817_DATA_STUFFING 1

#define NO_SQUAR_MC

//for ivc profile
#define IVC_PROFILE
#define BASELINE_PROFILE_ID    0x20

#define TRANS_2Nx2N    0
#define TRANS_NxN      1

#define TOTRUN_NUM    15

#define B_DIRECT_REMOVE

//--- block types for AEC ----
#define LUMA_8x8        2
#define CHROMA_DC       6
#define CHROMA_AC       7
#define NUM_BLOCK_TYPES 8

#define MAX_CODED_FRAME_SIZE 1500000         //!< bytes for one frame

#define TRACE           0                   //!< 0:Trace off 1:Trace on


#define MIN(a,b)  (((a)<(b)) ? (a) : (b))
#define MAX(a,b)  (((a)<(b)) ? (b) : (a))

#define absm(A) ((A)<(0) ? (-(A)):(A))      //!< abs macro, faster than procedure
#define MAX_VALUE       999999              //!< used for start value for some variables
#define Clip1(a)            ((a)>255?255:((a)<0?0:(a)))
#define Clip3(min,max,val) (((val)<(min))?(min):(((val)>(max))?(max):(val)))


#define P8x8    8
#define I_MB    9
#define I4MB   10
#define IBLOCK  11
#define SI4MB   12
#define MAXMODE 13

#define IS_INTRA(MB)    ((MB)->mb_type==I_MB)
#define IS_INTER(MB)    ((MB)->mb_type!=I_MB)
#define IS_DIRECT(MB)   ((MB)->mb_type==0   && (img->type ==    B_IMG ))
#define IS_COPY(MB)     ((MB)->mb_type==0   && (img->type == P_IMG))
#define IS_P8x8(MB)     ((MB)->mb_type==P8x8)

// Quantization parameter range
#define MIN_QP          0
#define MAX_QP          63

#define MB_SIZE   16 // the size of micro-block is 16x16
#define B8_SIZE    8
#define B4_SIZE    4
#define BLOCK_SIZE      4

#define MAX_IF_BUF    (MB_SIZE + 10)
#define MAX_IF_BUF_C  (MB_SIZE/2 + 4)

//luma intra mode
#define NO_INTRA_PMODE  5        //!< #intra prediction modes
/* 8x8 intra prediction modes */
#define VERT_PRED             0
#define HOR_PRED              1
#define DOWN_LEFT_PRED   3
#define DOWN_RIGHT_PRED  4
/* 8x8 intra prediction modes */
#define DC_PRED    2

//chroma intra mode
// 8x8 chroma intra prediction modes
#define HOR_PRED_8      1
#define VERT_PRED_8     2
#define PLANE_8         3
// 8x8 chroma intra prediction modes
#define DC_PRED_8       0

#define EOS             1     //!< End Of Sequence
#define SOP             2     //!< Start Of Picture

#define DECODING_OK     0
#define SEARCH_SYNC     1


#ifndef WIN32
#define max(a, b)      ((a) > (b) ? (a) : (b))  //!< Macro returning max value
#define min(a, b)      ((a) < (b) ? (a) : (b))  //!< Macro returning min value
#endif
#define mmax(a, b)      ((a) > (b) ? (a) : (b)) //!< Macro returning max value
#define mmin(a, b)      ((a) < (b) ? (a) : (b)) //!< Macro returning min value
#define clamp(a,b,c) ( (a)<(b) ? (b) : ((a)>(c)?(c):(a)) )    //!< clamp a to the range of [b;c]

// mv prediction
#define MVPRED_xy_MIN   0
#define MVPRED_L        1
#define MVPRED_U        2
#define MVPRED_UR       3
// mv prediction end

#define DECODE_MB       1

#define BLOCK_MULTIPLE      (MB_SIZE/(BLOCK_SIZE*2))

typedef signed long long   i64s_t;
typedef signed int         i32s_t;
typedef signed short       i16s_t;
typedef signed char        char_t;
typedef unsigned long long i64u_t;
typedef unsigned int       i32u_t;
typedef unsigned short     i16u_t;
typedef unsigned char      uchar_t;

#define COMPILE_FOR_8BIT 1

#if COMPILE_FOR_8BIT
typedef uchar_t   pel_t;
#else
typedef i16u_t    pel_t;
#endif

#if COMPILE_FOR_8BIT
#if defined(_WIN32)
#define ENABLE_AVX2 1
#define ENABLE_SSE  1
#define ENABLE_NEON 0
#else
#define ENABLE_AVX2 0
#define ENABLE_SSE  0
#define ENABLE_NEON 1
#endif
#endif

typedef i16s_t    coef_t;
typedef i16s_t    resi_t;

typedef unsigned char uchar;
typedef unsigned char bool;

#define IMG_PAD_SIZE (64+5+1)

#endif