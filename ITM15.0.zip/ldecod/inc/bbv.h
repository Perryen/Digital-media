/***************************************************************************************
This software is developed by Peking University, Tsinghua University and Zhejiang University etc. to be submitted to 
ISO/IEC JTC1/SC29/WG11 for evaluation as test platform of internet video coding. 
* Main Contributors include but are not limited as follows:   
Ronggang Wang, Peking University, Shenzhen Graduate School, rgwang@pkusz.edu.cn,   
Xianguo Zhang,   Peking University
Hao Lv,  Peking University, Shenzhen Graduate School
Zhenyu Wang,  Peking University, Shenzhen Graduate School
Xingguo Zhu,  Zhejiang University
Jianwen Chen,  Tsinghua University
Li Zhang,  Peking University
Siwei Ma,  Peking University
Qin Yu, Peking University
etc.
***************************************************************************************/

// ===================================================================================
//  File Name:   bbv.h
//  Description: bbv buffer for rate control
// -----------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------
//
// ===================================================================================

#ifndef  _BBV_H_
#define  _BBV_H_

#include "global.h"

BbvBuffer_t* init_bbv_memory(int frame_rate_code, int low_delay, int bbv_buffer_size, int bit_rate_upper, int bit_rate_lower);
BbvBuffer_t* free_bbv_memory(BbvBuffer_t* pBbv);
void stat_bbv_buffer(BbvBuffer_t* pBbv);
void update_bbv(BbvBuffer_t* pBbv, int code_bits);
void calc_min_BBS_size(int* FrameBits, int BitRate, float FrameRate, int FrameNum, int *Bmin_out, int *Fmin_out);


#endif //_BBV_H_