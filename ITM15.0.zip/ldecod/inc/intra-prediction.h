#ifndef INTRA_PREDICTION
#define INTRA_PREDICTION 

void xPredIntraLumaDC(unsigned char *pSrc, pel_t *pDst, int i_dst, int iBlkWidth, int iBlkHeight, bool bAboveAvail, bool bLeftAvail);
void xPredIntraVer(unsigned char *pSrc, pel_t *pDst, int i_dst, int iBlkWidth, int iBlkHeight);
void xPredIntraHor(unsigned char *pSrc, pel_t *pDst, int i_dst, int iBlkWidth, int iBlkHeight);
void xPredIntraDownRight(unsigned char *pSrc, pel_t *pDst, int i_dst, int iBlkWidth, int iBlkHeight);
void xPredIntraDownLeft(unsigned char *pSrc, pel_t *pDst, int i_dst, int iBlkWidth, int iBlkHeight);
void intra_pred_luma(unsigned char *pSrc, pel_t *pDst, int i_dst, int predmode, int uhBlkWidth, bool bAboveAvail, bool bLeftAvail);

void xIntraPredFilter(unsigned char *pSrc);
void intra_pred_chroma(unsigned char *pSrc, pel_t *pDst, int i_dst, int predmode, int x_off, int y_off, bool bAboveAvail, bool bLeftAvail);

#endif