/***************************************************************************************

***************************************************************************************/

#ifndef _AEC_H_
#define _AEC_H_

#include "global.h"

MotionInfoContexts* create_contexts_MotionInfo(void);
TextureInfoContexts* create_contexts_TextureInfo(void);
void init_contexts_MotionInfo(img_params *img, MotionInfoContexts *enco_ctx);
void init_contexts_TextureInfo(img_params *img, TextureInfoContexts *enco_ctx);
void delete_contexts_MotionInfo(MotionInfoContexts *enco_ctx);
void delete_contexts_TextureInfo(TextureInfoContexts *enco_ctx);

void AEC_new_slice();

void readMBTransType_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);

void readMBPartTypeInfo_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);
void read_8x8_PredTypeInfo_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);
void read_other_PredTypeInfo_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);

void MHMC_read_16x16_PredTypeInfo_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);
void MHMC_read_other_PredTypeInfo_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);

void readIntraSplite_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);
void readIntraPredMode_AEC(SyntaxElement *se,img_params *img, DecodingEnvironmentPtr dep_dp);
void readCIPredMode_AEC(SyntaxElement *se,img_params *img,DecodingEnvironmentPtr dep_dp);

extern int DCT_Block_Size;

void readMVD_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);
void readCBP_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);
void readRunLevel_AEC_Ref(SyntaxElement *se, img_params *img,  DecodingEnvironmentPtr dep_dp);
unsigned int biari_decode_symbolW(DecodingEnvironmentPtr dep, BiContextTypePtr bi_ct1, BiContextTypePtr bi_ct2 );
void readDquant_AEC(SyntaxElement *se,img_params *img,DecodingEnvironmentPtr dep_dp);

int  readSyntaxElement_AEC(SyntaxElement *se, img_params *img, DataPartition *this_dataPart);

void CheckAvailabilityOfNeighborsAEC();
unsigned int biari_decode_symbol_new(DecodingEnvironmentPtr dep, BiContextTypePtr bi_ct );
void readRunLenghtFromBuffer_AEC( SyntaxElement *se,
img_params *img,
	DecodingEnvironmentPtr dep_dp);


#endif  // _AEC_H_

void read_Reffrm_AEC(SyntaxElement *se, img_params *img, DecodingEnvironmentPtr dep_dp);