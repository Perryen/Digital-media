

void get_chroma_block(pel_t *pDst, int i_dst, int mv_x, int mv_y, int posx, int posy, uchar_t *refpic, int i_refc);
void get_luma_block(int x_pos, int y_pos, img_params *img, pel_t *pDst, int i_dst, uchar_t *ref_pic, int i_ref);
void SetMotionVectorPredictor (img_params  *img, int *pmv_x, int *pmv_y, int ref_frame, int **refFrArr, int ***tmp_mv, int block_x, int block_y, int blockshape_x, int ref);
void get_pred_mv(img_params *img, Macroblock *currMB, int b8, int bframe, int img_b8_x, int img_b8_y, int *vec1_x, int *vec1_y, int *vec2_x, int *vec2_y, int *refframe, int *fw_refframe, int *bw_refframe);
void get_chroma_mv_ref(img_params *img, Macroblock *currMB, int b8, int bframe, int img_b4_x, int img_b4_y, int *vec1_x, int *vec1_y, int *vec2_x, int *vec2_y, int *refframe, int *fw_refframe, int *bw_refframe);