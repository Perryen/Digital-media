/***************************************************************************************

***************************************************************************************/


/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/

#include "global.h"
#include "defines.h"

// ========================================================
// external variables
// ========================================================
extern const uchar QP_SCALE_CR[64] ;

extern const int IVC_SCAN4[16];
extern const int IVC_SCAN8[64];
extern const int IVC_SCAN16[256];

// functions
void inv_transform_B8(int* curr_blk, int bsize);
void get_curr_blk    (int b8, int b4, img_params *img, int* curr_blk, int bsize);
void idct_dequant_B8 (int b8, int b4,
					  int* curr_blk,
                      img_params *img,
                      int bsize );

int intrapred(img_params *img, uchar_t *pic_y, int img_x,int img_y, int bsize);
