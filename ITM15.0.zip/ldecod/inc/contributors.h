/***************************************************************************************

***************************************************************************************/



/*
*************************************************************************************
* File name:  contributors.h
* Function:   List of contributors and copyright information.
*
*************************************************************************************
*/

/*
 * \par 
    \verbatim
   The ISO/IEC JTC1/SC29/WG11 (MPEG). Internet Video Coding Test Model  encoder
  developed by
      Peking University, China
      Tsinghua University, China
      Zhejiang University, China
	  Hanyang University, Korean
	  Korea Aerospace University,Korean
  \endverbatim
  
 \par Full Contact Information
  \verbatim
  
  Ronggang Wang <rgwang@pkusz.edu.cn>
  Peking University Shenzhen Graduate School

  Xianguo Zhang,  
    Peking University
  Hao Lv, 
    Peking University, Shenzhen Graduate School
  Zhenyu Wang,
  Peking University Shenzhen Graduate School
  Siwei Ma,            <swma@pku.edu.cn>
  Peking University
  Li  Zhang            <zhanglili@jdl.ac.cn>
  Peking University
  Lei Chen
  Peking University, Shenzhen Graduate School
  Qin Yu
  Peking University

  Xingguo Zhu, 
  Zhejiang University

  Jianwen Chen         <jianwen.chen@gmail.com>
		 Dept.of E&E, Tsinghua University
		 Beijing China, 100084

   Kiho Choi,
   Hangyang University, aikiho@gmail.com

   Dong-Hyun Kim,
   Korea Aerospace University,dh.kim@kau.ac.kr
		
  \endverbatim
*/



