/***************************************************************************************

***************************************************************************************/
/*!
*************************************************************************************
* \file context_ini.h
*
* \brief
*    AEC context initializations
*
* \author
*    Main contributors (see contributors.h for copyright, address and affiliation details)
**************************************************************************************
*/


#ifndef _CONTEXT_INI_
#define _CONTEXT_INI_

void  init_contexts  (img_params* img);

#endif

