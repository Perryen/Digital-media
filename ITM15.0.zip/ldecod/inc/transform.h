

void inv_transform_B8(int* curr_blk, int bsize);

