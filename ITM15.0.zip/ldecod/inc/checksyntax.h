/***************************************************************************************

***************************************************************************************/



/*
*************************************************************************************
* File name: checksyntax.h
* Function:  Check bitstreams syntax
* Author:    
* Date:    
*
*************************************************************************************
*/


//Check deltaQP, ITM
#define CHECKDELTAQP if (img->qp+currMB->delta_quant > 63 || img->qp+currMB->delta_quant < 0) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(0)               (%3d|%3d) @ MB%d\n",currMB->delta_quant,img->qp+currMB->delta_quant, img->current_mb_nr); \
  }

//Check and restrict quantization coefficient's value, ITM
#define CHECKQCOEFF if (val > 2047) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(1)                %8d @(%d,%d) Blk%d MB%d\n",val,jj,ii,block8x8, img->current_mb_nr); \
  val = 2047; \
  } \
  else if (val < -2048) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(1)                %8d @(%d,%d) Blk%d MB%d\n",val,jj,ii,block8x8, img->current_mb_nr); \
  val = -2048; \
  }

//Check and restirct IDCT input value, ITM
#define CHECKDCTVALUE if (sum > 8191) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(2)                %8d @(%d,%d) Blk%d MB%d\n",sum,jj,ii,block8x8, img->current_mb_nr); \
  sum = 8191; \
  } \
  else if (sum < -8192) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(2)                %8d @(%d,%d) Blk%d MB%d\n",sum,jj,ii,block8x8, img->current_mb_nr); \
  sum = -8192; \
  }

//Check MVD's range, ITM
#define CHECKMVDRANGE if ((curr_mvd>4095 || curr_mvd<-4096)) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(3)                %8d @ Blk%d MB%d\n", curr_mvd,2*j0+i0, img->current_mb_nr); \
  } 

//Check MV's range, ITM
#define CHECKMOTIONRANGE if (vec_x > (horizontal_size*4+32) || vec_x < -64 || mv_x > Max_H_MV || mv_x < Min_H_MV) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(4)       %s(Hor):(%5d|%5d) @ Blk%d MB%d\n", is_fwd==1?"Fwd":"Bwd", mv_x,vec_x/4,block8x8, \
  img->current_mb_nr); \
  } \
  if (vec_y > (vertical_size*4+32) || vec_y < -64 || mv_y > Max_V_MV || mv_y < Min_V_MV) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"error(4)       %s(Ver):(%5d|%5d) @ Blk%d MB%d\n", is_fwd==1?"Fwd":"Bwd", mv_y,vec_y/4,block8x8, \
  img->current_mb_nr); \
  }

//Check marker_bit, ITM_r2
#define CHECKMARKERBIT if (!marker_bit) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport,"\nInvalid marker_bit value at %s! (marker_bit after %s)\n", spos0, spos1); \
  }

//Check no_forward_reference_flag, ITM_r2
#define CHECKMOTIONDIRECTION if (img->no_forward_reference) \
  { \
  CSyntax = 0; \
  fprintf(p_sreport, "ERROR! no_forward_reference_flag is set to 1. Forward Motion Prediction is found at MBIndex %d\n", \
  img->current_mb_nr); \
    }