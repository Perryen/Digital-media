/***************************************************************************************

***************************************************************************************/



/*
*************************************************************************************
* File name: golomb_dec.h
* Function: Description
*
*************************************************************************************
*/


#ifndef GOLOMB_H
#define GOLOMB_H

#include "global.h"

unsigned int decode_golomb_word(unsigned char **buffer,unsigned int *bitoff,unsigned int grad0,unsigned int max_levels);

void tracebits3(
                const char *trace_str,  //!< tracing information, char array describing the symbol
                int len,                //!< length of syntax element in bits
                int info,               //!< infoword of syntax element
                int value1);
#endif
