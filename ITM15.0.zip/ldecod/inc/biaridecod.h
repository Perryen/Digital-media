/***************************************************************************************

***************************************************************************************/
/*!
***************************************************************************
* \file
*    biaridecod.h
*
* \brief
*    Headerfile for binary arithmetic decoder routines
*
* \author
*    Ping Yang                                                         
*
**************************************************************************
*/

#ifndef _BIARIDECOD_H_
#define _BIARIDECOD_H_


/************************************************************************
* D e f i n i t i o n s
***********************************************************************
*/

void arideco_start_decoding(DecodingEnvironmentPtr eep, unsigned char *code_buffer, int firstbyte, int *code_len);
int  arideco_bits_read(DecodingEnvironmentPtr dep);
void arideco_done_decoding(DecodingEnvironmentPtr dep);
void biari_init_context_logac (BiContextTypePtr ctx);

void rescale_cum_freq(BiContextTypePtr bi_ct);
unsigned int biari_decode_symbol(DecodingEnvironmentPtr dep, BiContextTypePtr bi_ct );
unsigned int biari_decode_symbolW(DecodingEnvironmentPtr dep, BiContextTypePtr bi_ct1, BiContextTypePtr bi_ct2 );
unsigned int biari_decode_symbol_eq_prob(DecodingEnvironmentPtr dep);
unsigned int biari_decode_final(DecodingEnvironmentPtr dep);

#endif  // BIARIDECOD_H_

