#include "common.h"
#include "defines.h"

const int cst_log_level = 2;

funs_handle_t g_funs_handle;

#if DEBUG_TEST
FILE* g_debug_fp = NULL;
#endif

/****************************************************************************
 * com_malloc: malloc & free
 ****************************************************************************/
void *com_malloc(int i_size)
{
    int mask = ALIGN_BASIC - 1;
    uchar *align_buf;
    uchar *buf = (uchar *)malloc(i_size + mask + sizeof(void **));

    if (buf) {
        align_buf = buf + mask + sizeof(void **);
        align_buf -= (intptr_t)align_buf & mask;
        *(((void **)align_buf) - 1) = buf;
    } else {
        printf("Error: malloc of size %d failed\n");
    }
    memset(align_buf, 0, i_size);
    return align_buf;
}

void com_free(void *p)
{
    if (p) {
        free(*(((void **)p) - 1));
    } else {
        printf("free a NULL pointer\n");
    }
}