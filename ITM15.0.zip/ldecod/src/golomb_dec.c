/***************************************************************************************

***************************************************************************************/


/*
*************************************************************************************
* File name: golomb_dec.c
* Function: Description
*
*************************************************************************************
*/

#include <assert.h>
#include "golomb_dec.h"
#include "global.h"

extern BbvBuffer_t *pBbv;  

#if TRACE
/*
*************************************************************************
* Function:
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void encode_golomb_word(unsigned int symbol,unsigned int grad0,unsigned int max_levels,unsigned int *res_bits,unsigned int *res_len)
{
  unsigned int level,res,numbits;
  res=1UL<<grad0;
  level=1UL;numbits=1UL+grad0;
  //find golomb level
  while( symbol>=res && level<max_levels )
  {
    symbol-=res;
    res=res<<1;
    level++;
    numbits+=2UL;
  }
  if(level>=max_levels)
  {
    if(symbol>=res)
      symbol=res-1UL;  //crop if too large.
  }
  //set data bits
  *res_bits=res|symbol;
  *res_len=numbits;
}

void encode_multilayer_golomb_word(unsigned int symbol,const unsigned int *grad,const unsigned int *max_levels,unsigned int *res_bits,unsigned int *res_len)
{
  unsigned accbits,acclen,bits,len,tmp;
  accbits=acclen=0UL;
  while(1)
  {
    encode_golomb_word(symbol,*grad,*max_levels,&bits,&len);
    accbits=(accbits<<len)|bits;
    acclen+=len;
    assert(acclen<=32UL);  //we'l be getting problems if this gets longer than 32 bits.
    tmp=*max_levels-1UL;
    if(!(( len == (tmp<<1)+(*grad) )&&( bits == (1UL<<(tmp+*grad))-1UL )))  //is not last possible codeword? (Escape symbol?)
      break;
    tmp=*max_levels;
    symbol-=(((1UL<<tmp)-1UL)<<(*grad))-1UL;
    grad++;max_levels++;
  }
  *res_bits=accbits;
  *res_len=acclen;
}
#endif

unsigned int decode_golomb_word(unsigned char **buffer,unsigned int *bitoff,unsigned int grad0,unsigned int max_levels)
{
  unsigned char *rd;
  unsigned int bit,byte,level,databits,t,testbit;
  rd=*buffer;
  bit=*bitoff;
  byte=*rd;
  level=0UL;
  while( level<max_levels )//( level+1UL<max_levels )
  {
    testbit=byte&(1UL<<bit);
    bit = (bit-1UL) & 7UL ;
    if(bit==7UL)byte=*(++rd);
    if( testbit )break;
    level++;
  }
  databits=0UL;
  for( t=0UL ; t<(grad0+level) ; t++ )
  {
    databits = (databits<<1UL) | ((byte>>bit)&1UL) ;
    bit = (bit-1UL) & 7UL ;
    if(bit==7UL)byte=*(++rd);
  }
  *buffer=rd;
  *bitoff=bit;
  return (((1UL<<level)-1UL)<<grad0)+databits;
}