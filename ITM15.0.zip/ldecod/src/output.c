/***************************************************************************************

***************************************************************************************/

/*
*************************************************************************************
* File name:  output.c
* Function: Output an image and Trance support
*
*************************************************************************************
*/
#include "contributors.h"
#include "global.h"
#include <stdlib.h>
#include <string.h>
#ifdef WIN32
#include <IO.H>
#endif

/*
*************************************************************************
* Function:Write decoded frame to output file
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void write_frame(img_params *img, FILE *p_out)
{
  int i, j;
  int img_width = (img->width-img->auto_crop_right);
  int img_height = (img->height-img->auto_crop_bottom);
  int img_width_cr = (img_width/2);
  int img_height_cr = (img_height/ 2);
  int iStride = img->iStride;
  int iStrideC = img->iStrideC;

    for(i=0;i<img_height;i++)
      for(j=0;j<img_width;j++)
       fputc(imgY_rec[i*iStride+j],p_out);

    for(i=0;i<img_height_cr;i++)
      for(j=0;j<img_width_cr;j++)
        fputc(imgU_rec[i*iStrideC+j],p_out);

    for(i=0;i<img_height_cr;i++)
      for(j=0;j<img_width_cr;j++)
		  fputc(imgV_rec[i*iStrideC+j],p_out);

    fflush(p_out);
}

/*
*************************************************************************
* Function:Write previous decoded P frame to output file
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void write_prev_Pframe(img_params *img, FILE *p_out, uchar_t *pDst)
{
  int img_org_width = (img->width-img->auto_crop_right);
  int img_org_height = (img->height-img->auto_crop_bottom);

  fwrite(pDst, img_org_width*img_org_height*3/2, sizeof(uchar_t), p_out);
  //fflush(p_out);
}

#if TRACE
static int bitcounter = 0;

/*
*************************************************************************
* Function:Tracing bitpatterns for symbols
A code word has the following format: 0 Xn...0 X2 0 X1 0 X0 1
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/

void tracebits(
               const char *trace_str,  //!< tracing information, char array describing the symbol
               int len,                //!< length of syntax element in bits
               int info,               //!< infoword of syntax element
               int value1)
{

  int i, chars;

  if(len>=34)
  {
    snprintf(errortext, ET_SIZE, "Length argument to put too long for trace to work");
    error (errortext, 600);
  }

  putc('@', p_trace);
  chars = fprintf(p_trace, "%i", bitcounter);
  while(chars++ < 6)
    putc(' ',p_trace);

  chars += fprintf(p_trace, "%s", trace_str);
  while(chars++ < 55)
    putc(' ',p_trace);

  // Align bitpattern
  if(len<15)
  {
    for(i=0 ; i<15-len ; i++)
      fputc(' ', p_trace);
  }

  // Print bitpattern
  for(i=0 ; i<len/2 ; i++)
  {
    fputc('0', p_trace);
  }
  // put 1
  fprintf(p_trace, "1");

  // Print bitpattern
  for(i=0 ; i<len/2 ; i++)
  {
    if (0x01 & ( info >> ((len/2-i)-1)))
      fputc('1', p_trace);
    else
      fputc('0', p_trace);
  }

  fprintf(p_trace, "  (%3d)\n", value1);
  bitcounter += len;

  fflush (p_trace);

}

/*
*************************************************************************
* Function:Tracing bitpatterns 
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/


void tracebits2(
                const char *trace_str,  //!< tracing information, char array describing the symbol
                int len,                //!< length of syntax element in bits
                int info)
{

  int i, chars;

  if(len>=45)
  {
    snprintf(errortext, ET_SIZE, "Length argument to put too long for trace to work");
    error (errortext, 600);
  }

  putc('@', p_trace);
  chars = fprintf(p_trace, "%i", bitcounter);
  while(chars++ < 6)
    putc(' ',p_trace);
  chars += fprintf(p_trace, "%s", trace_str);
  while(chars++ < 55)
    putc(' ',p_trace);

  // Align bitpattern
  if(len<15)
    for(i=0 ; i<15-len ; i++)
      fputc(' ', p_trace);

  bitcounter += len;
  while (len >= 32)
  {
    for(i=0 ; i<8 ; i++)
    {
      fputc('0', p_trace);
    }
    len -= 8;

  }
  // Print bitpattern
  for(i=0 ; i<len ; i++)
  {
    if (0x01 & ( info >> (len-i-1)))
      fputc('1', p_trace);
    else
      fputc('0', p_trace);
  }

  fprintf(p_trace, "  (%3d)\n", info);

  fflush (p_trace);

}

/*
*************************************************************************
* Function:Tracing bitpatterns for symbols
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/


void tracebits3(
                const char *trace_str,  //!< tracing information, char array describing the symbol
                int len,                //!< length of syntax element in bits
                int info,               //!< infoword of syntax element
                int value1)
{
  int i, chars;

  if(len>=34)
  {
    snprintf(errortext, ET_SIZE, "Length argument to put too long for trace to work");
    error (errortext, 600);
  }

  putc('@', p_trace);
  chars = fprintf(p_trace, "%i", bitcounter);
  while(chars++ < 6)
    putc(' ',p_trace);

  chars += fprintf(p_trace, "%s", trace_str);
  while(chars++ < 55)
    putc(' ',p_trace);

  // Align bitpattern
  if(len<15)
  {
    for(i=0 ; i<15-len ; i++)
      fputc(' ', p_trace);
  }

  // Print bitpattern
  for(i=0 ; i<len ; i++)
  {
    if (0x01 & ( info >> (len-i-1)))
      fputc('1', p_trace);
    else
      fputc('0', p_trace);
  }

  fprintf(p_trace, "  (%3d)\n", value1);
  bitcounter += len;

  fflush (p_trace);

}
#endif
