/***************************************************************************************

***************************************************************************************/




/*
*************************************************************************************
* File name: b_frame.c
* Function: B picture decoding
*
*************************************************************************************
*/


#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "global.h"
#include "b_frame.h"

/*
*************************************************************************
* Function:Copy decoded P frame to temporary image array
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void copy_Pframe(img_params *img, uchar_t *pDst)
{
	int i,j;
	int img_org_width = img->width - img->auto_crop_right;
	int img_org_height = img->height - img->auto_crop_bottom;

	int img_org_widthc = img_org_width >> 1;
	int img_org_heightc = img_org_height >> 1;

	int iStride = img->iStride;
	int iStrideC = img->iStrideC;
	/*
	* the mmin, mmax macros are taken out
	* because it makes no sense due to limited range of data type
	*/

	for(i=0;i<img_org_height;i++){
		for(j=0;j<img_org_width;j++){
			*pDst++ = imgY_rec[i*iStride+j];
		}
	}

	for(i=0;i<img_org_heightc;i++){
		for(j=0;j<img_org_widthc;j++){
			*pDst++ = imgU_rec[i*iStrideC+j];
		}
	}

	for(i=0;i<img_org_heightc;i++){
		for(j=0;j<img_org_widthc;j++){
			*pDst++ = imgV_rec[i*iStrideC+j];
		}
	}

}

/*
*************************************************************************
* Function:init macroblock B frames
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/

void init_macroblock_Bframe(img_params *img)
{
  int i,j,k;
  Macroblock *currMB = &mb_data[img->current_mb_nr];//GB current_mb_nr];
  // reset vectors and pred. modes
  for (i=0;i<2;i++)
  {
    for(j=0;j<2;j++)
    {
      img->dfMV [img->block_x+i+4][img->block_y+j][0]=img->dfMV[img->block_x+i+4][img->block_y+j][1]=0;
      img->dbMV [img->block_x+i+4][img->block_y+j][0]=img->dbMV[img->block_x+i+4][img->block_y+j][1]=0;

      img->fw_mv[img->block_x+i+4][img->block_y+j][0]=img->fw_mv[img->block_x+i+4][img->block_y+j][1]=0;
      img->bw_mv[img->block_x+i+4][img->block_y+j][0]=img->bw_mv[img->block_x+i+4][img->block_y+j][1]=0;
    }
  }

  // Set the reference frame information for motion vector prediction
  if (IS_INTRA (currMB) || IS_DIRECT (currMB))
  {
    for (j=0; j<2; j++)
      for (i=0; i<2; i++)
      {
        img->fw_refFrArr[img->block_y+j][img->block_x+i] = -1;
        img->bw_refFrArr[img->block_y+j][img->block_x+i] = -1;
      }
  }
  else
  {
    for(j=0;j<2;j++)
      for(i=0;i<2;i++)
      {
        k=2*j+i;

        img->fw_refFrArr[img->block_y+j][img->block_x+i] = ((currMB->b8pdir[k]==0||currMB->b8pdir[k]==2)&&currMB->b8mode[k]!=0?0:-1);
        img->bw_refFrArr[img->block_y+j][img->block_x+i] = ((currMB->b8pdir[k]==1||currMB->b8pdir[k]==2)&&currMB->b8mode[k]!=0?0:-1);
      }
  }
}
