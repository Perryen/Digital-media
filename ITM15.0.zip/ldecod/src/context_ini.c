/***************************************************************************************

***************************************************************************************/
/*!
*************************************************************************************
* \file context_ini.c
*
* \brief
*    AEC context initializations
*
* \author
*    Main contributors (see contributors.h for copyright, address and affiliation details)
**************************************************************************************
*/

#define CONTEXT_INI_C

#include "defines.h"
#include "global.h"
#include "biaridecod.h"


#define BIARI_CTX_INIT1_LOG(jj,ctx)\
{\
	for (j=0; j<jj; j++)\
	{\
	biari_init_context_logac(&(ctx[j]));\
	}\
}

#define BIARI_CTX_INIT2_LOG(ii,jj,ctx)\
{\
	for (i=0; i<ii; i++)\
	for (j=0; j<jj; j++)\
	{\
	biari_init_context_logac(&(ctx[i][j]));\
	}\
}

#define BIARI_CTX_INIT3_LOG(ii,jj,kk,ctx)\
{\
	for (i=0; i<ii; i++)\
	for (j=0; j<jj; j++)\
	for (k=0; k<kk; k++)\
	{\
	biari_init_context_logac(&(ctx[i][j][k]));\
	}\
}

#define BIARI_CTX_INIT4_LOG(ii,jj,kk,ll,ctx)\
{\
	for (i=0; i<ii; i++)\
	for (j=0; j<jj; j++)\
	for (k=0; k<kk; k++)\
	for (l=0; l<ll; l++)\
	{\
	biari_init_context_logac(&(ctx[i][j][k][l]));\
	}\
}





void init_contexts (img_params* img)
{
	MotionInfoContexts*  mc = img->currentSlice->mot_ctx;
	TextureInfoContexts* tc = img->currentSlice->tex_ctx;
	int i, j;
    BIARI_CTX_INIT1_LOG(1, tc->qsplit_contexts);
	BIARI_CTX_INIT1_LOG (                 NUM_IPR_CTX,  tc->ipr_contexts);
	BIARI_CTX_INIT1_LOG (                 NUM_CIPR_CTX, tc->cipr_contexts);

	//--- motion coding contexts ---
	BIARI_CTX_INIT2_LOG (3, NUM_MB_TYPE_CTX,   mc->mb_type_contexts);
	BIARI_CTX_INIT2_LOG (2, NUM_B8_TYPE_CTX,   mc->b8_type_contexts);
	BIARI_CTX_INIT2_LOG (2, NUM_MV_RES_CTX,    mc->mv_res_contexts);
	BIARI_CTX_INIT1_LOG (   NUM_DELTA_QP_CTX,  mc->delta_qp_contexts);
	//--- texture coding contexts ---
	BIARI_CTX_INIT2_LOG (3,               NUM_CBP_CTX,  tc->cbp_contexts);
	//BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_BCBP_CTX, tc->bcbp_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_ONE_CTX,  tc->one_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_ABS_CTX,  tc->abs_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_MAP_CTX,  tc->map_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_LAST_CTX, tc->last_contexts);
    BIARI_CTX_INIT1_LOG (1,  tc->tu_size_context);
}

