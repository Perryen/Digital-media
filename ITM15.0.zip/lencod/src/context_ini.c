/***************************************************************************************

***************************************************************************************/
/*!
*************************************************************************************
* \file context_ini.c
*
* \brief
*    AEC context initializations
*
* \author
*    Main contributors (see contributors.h for copyright, address and affiliation details)
**************************************************************************************
*/

#define CONTEXT_INI_C

#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <string.h>

#include "defines.h"
#include "global.h"

#include "AEC.h"

#define DEFAULT_CTX_MODEL   0
#define RELIABLE_COUNT      32.0
#define FRAME_TYPES         4
#define FIXED               0


int                     num_mb_per_slice;
int                     number_of_slices;


#define BIARI_CTX_INIT1_LOG(jj,ctx)\
{\
	for (j=0; j<jj; j++)\
{\
	biari_init_context_logac(&(ctx[j]));\
}\
}

#define BIARI_CTX_INIT2_LOG(ii,jj,ctx)\
{\
	for (i=0; i<ii; i++)\
	for (j=0; j<jj; j++)\
{\
	biari_init_context_logac(&(ctx[i][j]));\
}\
}



void init_contexts ()
{
	MotionInfoContexts*  mc = img->currentSlice->mot_ctx;
	TextureInfoContexts* tc = img->currentSlice->tex_ctx;
	int i, j;

	//--- motion coding contexts ---
	BIARI_CTX_INIT2_LOG (3, NUM_MB_TYPE_CTX,   mc->mb_type_contexts);
	BIARI_CTX_INIT2_LOG (2, NUM_B8_TYPE_CTX,   mc->b8_type_contexts);
	BIARI_CTX_INIT2_LOG (2, NUM_MV_RES_CTX,    mc->mv_res_contexts);
	BIARI_CTX_INIT1_LOG (   NUM_DELTA_QP_CTX,  mc->delta_qp_contexts);

	//--- texture coding contexts ---
    BIARI_CTX_INIT1_LOG(1, tc->qsplit_contexts);
	BIARI_CTX_INIT1_LOG (                 NUM_IPR_CTX,  tc->ipr_contexts);
	BIARI_CTX_INIT1_LOG (                 NUM_CIPR_CTX, tc->cipr_contexts);
	BIARI_CTX_INIT2_LOG (3,               NUM_CBP_CTX,  tc->cbp_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_ABS_CTX,  tc->abs_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_MAP_CTX,  tc->map_contexts);
	BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_LAST_CTX, tc->last_contexts);
    BIARI_CTX_INIT2_LOG (NUM_BLOCK_TYPES, NUM_ONE_CTX,  tc->one_contexts)
    BIARI_CTX_INIT1_LOG (                 1, tc->tu_size_context);
}


