/*****************************************************************************
* Copyright (C) 2016 xIVC project, Peking University Shenzhen Graduate School
*
* Authors: Ronggang Wang <rgwang@pkusz.edu.cn>
*		   Zhenyu Wang <wangzhenyu@pkusz.edu.cn>
*          Kui Fan <kuifan@pku.edu.cn>
*		   Shenghao Zhang <1219759986@qq.com>
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02111, USA.
*
* This program is also available under a commercial proprietary license.
* For more information, contact us at rgwang@pkusz.edu.cn.
*****************************************************************************/
#include "common.h"
#include "defines.h"

const int cst_log_level = 2;

funs_handle_t g_funs_handle;

#if DEBUG_TEST
FILE* g_debug_fp = NULL;
#endif
//
///****************************************************************************
// * com_malloc: malloc & free
// ****************************************************************************/
//void *com_malloc(int i_size)
//{
//    int mask = ALIGN_BASIC - 1;
//    uchar *align_buf;
//    uchar *buf = (uchar *)malloc(i_size + mask + sizeof(void **));
//
//    if (buf) {
//        align_buf = buf + mask + sizeof(void **);
//        align_buf -= (intptr_t)align_buf & mask;
//        *(((void **)align_buf) - 1) = buf;
//    } else {
//        printf("Error: malloc of size %d failed\n");
//    }
//    memset(align_buf, 0, i_size);
//    return align_buf;
//}
//
//void com_free(void *p)
//{
//    if (p) {
//        free(*(((void **)p) - 1));
//    } else {
//        printf("free a NULL pointer\n");
//    }
//}