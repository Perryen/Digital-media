#include "defines.h"
#include "global.h"

//void com_if_filter_cpy(const pel_t *src, int i_src, int *dst, int i_dst, int width, int height)
//{
//	int row;
//	for (row = 0; row < height; row++) {
//		memcpy(dst, src, sizeof(pel_t)* width);
//		src += i_src;
//		dst += i_dst;
//	}
//}