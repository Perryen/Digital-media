/***************************************************************************************

***************************************************************************************/
/*!
*************************************************************************************
* \file biariencode.c
*
* \brief
*    Routines for binary arithmetic encoding
* \author
*    Main contributors (see contributors.h for copyright, address and affiliation details)
*************************************************************************************
*/
#include <stdlib.h>
#include <math.h>
#include "global.h"
#include "AEC.h"
#include "biariencode.h"
#include <assert.h>


//AC ENGINE PARAMETERS
unsigned int s1,t1,s2,t2;

/*!
************************************************************************
* Macro for writing bytes of code
***********************************************************************
*/

#define put_byte() { \
  Ecodestrm[(*Ecodestrm_len)++] = Ebuffer; \
  Ebits_to_go = 8; \
  while (eep->C > 7) { \
  eep->C-=8; \
  eep->E++; \
  } \
} 

#define put_one_bit(b) { \
  Ebuffer <<= 1; Ebuffer |= (b); \
  if (--Ebits_to_go == 0) \
  put_byte(); \
}

#define put_one_bit_plus_outstanding(b) { \
  put_one_bit(b); \
  while (Ebits_to_follow > 0) \
{ \
  Ebits_to_follow--; \
  put_one_bit(!(b)); \
} \
}



/*!
************************************************************************
* \brief
*    Allocates memory for the EncodingEnvironment struct
************************************************************************
*/
EncodingEnvironmentPtr arienco_create_encoding_environment()
{
  EncodingEnvironmentPtr eep;
  if ( (eep = (EncodingEnvironmentPtr) calloc(1,sizeof(EncodingEnvironment))) == NULL)
    no_mem_exit("arienco_create_encoding_environment: eep");
  return eep;
}


/*!
************************************************************************
* \brief
*    Frees memory of the EncodingEnvironment struct
************************************************************************
*/
void arienco_delete_encoding_environment(EncodingEnvironmentPtr eep)
{
  if( eep==NULL ) {
    snprintf(errortext, ET_SIZE, "Error freeing eep (NULL pointer)");
    error (errortext, 200);
  }
  else
    free(eep);
}

/*!
************************************************************************
* \brief
*    Initializes the EncodingEnvironment for the arithmetic coder
************************************************************************
*/

void arienco_start_encoding(EncodingEnvironmentPtr eep,
                            byte *code_buffer,
                            int *code_len, int slice_type )
{	
  Ecodestrm = code_buffer;
  Ecodestrm_len = code_len;
  Elow = 0;
  E_s1 = 0;
  E_t1 = 0xFF;
  Ebits_to_follow  =0 ;
  Ebuffer = 0;
  Ebits_to_go = 9;// to swallow first redundant bit
  s2=0;
  t2=0xff;
  eep->C = 0;
  eep->B = *code_len;
  eep->E = 0;

}

/*!
************************************************************************
* \brief
*    Returns the number of currently written bits
************************************************************************
*/
int arienco_bits_written(EncodingEnvironmentPtr eep)
{
  return ( 8*(*Ecodestrm_len /*-*Ecodestrm_laststartcode*/) + Ebits_to_follow + 8 - Ebits_to_go + E_s1);
}


/*!
************************************************************************
* \brief
*    Terminates the arithmetic codeword, writes stop bit and stuffing bytes (if any)
************************************************************************
*/

void arienco_done_encoding(EncodingEnvironmentPtr eep)
{
  int i;
  put_one_bit_plus_outstanding((Elow >> (B_BITS-1)) & 1); //д��Ebits_to_follow+1λ
  put_one_bit((Elow >> (B_BITS-2))&1); //1bit
  //put_one_bit(0);   //1 bit         //multiple slice, yuanyuan
  put_one_bit(1);                   
  for(i=0;i<8;i++)
    put_one_bit(0);


  stat->bit_use_stuffingBits[img->type]+=(8-Ebits_to_go);
  //while (Ebits_to_go != 8)          //multiple slice, yuanyuan
  //	put_one_bit(0);

  eep->E= eep->E*8 + eep->C; // no of processed bins
  eep->B= (*Ecodestrm_len - eep->B); // no of written bytes
  eep->E -= (img->current_mb_nr-img->currentSlice->start_mb_nr);
  eep->E = (eep->E + 31)>>5;
  // eep->E now contains the minimum number of bytes for the NAL unit
}


/*!
************************************************************************
* \brief
*    Actually arithmetic encoding of one binary symbol by using
*    the probability estimate of its associated context model
************************************************************************
*/
//Logarithm arithmetic coder by Tsinghua
void biari_encode_symbol(EncodingEnvironmentPtr eep, unsigned char symbol, BiContextTypePtr bi_ct)//type 0 normal,1 equal,2 final
{	
  unsigned char cycno = bi_ct->cycno;
  unsigned int low = Elow;
  unsigned char cwr=0;

  unsigned int lg_pmps = bi_ct->LG_PMPS;
  unsigned int t_rLPS=0;
  unsigned char s_flag=0,is_LPS=0;

  unsigned int  curr_byte=0;
  short int bitstogo=0;
  unsigned char bit_o=0,bit_oa=0,byte_no=0;
  unsigned int low_byte[3]={0};
  static int bits_counter=0;

  if (AEC_writting==1)
    bits_counter++;
  s1 = E_s1;
  t1 = E_t1;
  if (AEC_writting==1)
    low_byte[0]=0;
  low_byte[1]=0;
  low_byte[2]=0;

  assert(eep!=NULL);

  cwr = (cycno<=1)?3:(cycno==2)?4:5;

  if (symbol != 0) 
    symbol = 1;	

  if (t1>=(lg_pmps>>LG_PMPS_SHIFTNO))
  {
    s2 = s1;
    t2 = t1 - (lg_pmps>>LG_PMPS_SHIFTNO);
    s_flag = 0;
  }
  else
  {
    s2 = s1+1;
    t2 = 256 + t1 - (lg_pmps>>LG_PMPS_SHIFTNO); 
    s_flag = 1;
  }

  if (symbol==bi_ct->MPS) //MPS happens
  {

    if (cycno==0) cycno =1;
    s1 = s2;
    t1 = t2;

    //no updating of interval range and low here or
    //renorm to guarantee s1<8, after renorm, s1 --;
    if (s1 == 8) //renorm
    {
      //left shift 1 bit	

      bit_o = (low>>9) &1;		

      {			
        bit_oa = (low>>8) &1;

        if (bit_o) 
        {	
          put_one_bit_plus_outstanding( 1);

        }
        else
        {				
          if (!bit_oa)//00
          {
            put_one_bit_plus_outstanding( 0);
          }
          else {//01
            Ebits_to_follow++;				
            bit_oa = 0;
          }
        }
        s1--;			
      }

      //restore low
      low = ((bit_oa<<8) | (low & 0xff))<<1;
    }
  }
  else //--LPS
  {
    is_LPS = 1;
    cycno=(cycno<=2)?(cycno+1):3;

    if (s_flag==0)
      t_rLPS = lg_pmps>>LG_PMPS_SHIFTNO;//t_rLPS -- 9bits
    else //s2=s1 + 1
      t_rLPS = t1 + (lg_pmps>>LG_PMPS_SHIFTNO); //t_rLPS<HALF

    low_byte[0] = low + ((t2+256)>>s2); //first low_byte: 10bits
    low_byte[1] = (t2<<(8-s2)) & 0xff;

    //restore range		
    while (t_rLPS<QUARTER){
      t_rLPS = t_rLPS<<1;
      s2 ++;
    }	

    //left shift s2 bits
    {		
      curr_byte = low_byte[0];
      bitstogo = 9;
      bit_oa = (curr_byte>>bitstogo) &1;
      byte_no = 0;

      while (s2>0)
      {
        bit_o = bit_oa;
        bitstogo--;
        if (bitstogo<0)
        {
          curr_byte = low_byte[++byte_no];
          bitstogo = 7;
        }
        bit_oa = (curr_byte>>bitstogo) &1;

        if (bit_o) 
        {
          put_one_bit_plus_outstanding(1);
        }
        else
        {				
          if (!bit_oa)//00
          {
            put_one_bit_plus_outstanding( 0);
          }
          else {//01
            Ebits_to_follow++;				
            bit_oa = 0;
          }
        }
        s2--;			
      }

      //restore low
      low = bit_oa;
      s2 = 9;
      while (s2>0)
      {			
        bitstogo--;
        if (bitstogo<0)
        {
          curr_byte = low_byte[++byte_no];
          bitstogo = 7;
        }
        bit_oa = (curr_byte>>bitstogo) &1;
        low = (low<<1) | bit_oa;
        s2--;
      }
    }

    s1 = 0;
    t1 = t_rLPS & 0xff;	
  }

  //updating other parameters
  bi_ct->cycno = cycno;
  Elow = low;
  E_s1 = s1;
  E_t1 = t1;
  eep->C++;

  //update probability estimation
  if (is_LPS)
  {	
    switch(cwr) {
    case 3:	lg_pmps = lg_pmps + 197;					
      break;
    case 4: lg_pmps = lg_pmps + 95;
      break;
    default:lg_pmps = lg_pmps + 46; 
    }

    if (lg_pmps>=(256<<LG_PMPS_SHIFTNO))
    {
      lg_pmps = (512<<LG_PMPS_SHIFTNO) - 1 - lg_pmps;
      bi_ct->MPS = !(bi_ct->MPS);
    }	
  }
  else
  {
    lg_pmps = lg_pmps - (unsigned int)(lg_pmps>>cwr) - (unsigned int)(lg_pmps>>(cwr+2));	
  }	
  bi_ct->LG_PMPS = lg_pmps;


}



void biari_encode_symbolW(EncodingEnvironmentPtr eep, unsigned char symbol, BiContextTypePtr bi_ct1, BiContextTypePtr bi_ct2)
{

  unsigned int low = Elow;
  unsigned int cwr1=0,cycno1=bi_ct1->cycno;
  unsigned int cwr2=0,cycno2=bi_ct2->cycno;
  unsigned int lg_pmps1= bi_ct1->LG_PMPS,lg_pmps2= bi_ct2->LG_PMPS;
  unsigned char bit1=bi_ct1->MPS,bit2=bi_ct2->MPS; 

  unsigned int t_rLPS=0;	
  unsigned char s_flag=0,is_LPS=0;

  unsigned char pred_MPS=0;
  unsigned int  lg_pmps=0;

  unsigned int low_byte[3]={0};

  unsigned int  curr_byte=0;	
  short int bitstogo=0;
  unsigned char bit_o=0,bit_oa=0,byte_no=0;
  unsigned char eBuffer = Ebuffer;

  if (AEC_writting==1)
    low_byte[0]=0;
  low_byte[1]=0;
  low_byte[2]=0;
  s1 = E_s1;
  t1 = E_t1;		

  assert(eep!=NULL);
  cwr1 = (cycno1<=1)?3:(cycno1==2)?4:5;
  cwr2 = (cycno2<=1)?3:(cycno2==2)?4:5; 

  if (symbol != 0) 
    symbol = 1;	

  if (bit1 == bit2) 
  {
    pred_MPS = bit1;
    lg_pmps = (lg_pmps1 + lg_pmps2)/2;
  }
  else 
  {
    if (lg_pmps1<lg_pmps2) {
      pred_MPS = bit1;
      lg_pmps = (256<<LG_PMPS_SHIFTNO) - 1 - ((lg_pmps2 - lg_pmps1)>>1);
    }
    else {
      pred_MPS = bit2;
      lg_pmps = (256<<LG_PMPS_SHIFTNO) - 1 - ((lg_pmps1 - lg_pmps2)>>1);
    }
  }

  if (t1>=(lg_pmps>>LG_PMPS_SHIFTNO))
  {
    s2 = s1;
    t2 = t1 - (lg_pmps>>LG_PMPS_SHIFTNO);
    s_flag = 0;
  }
  else
  {
    s2 = s1+1;
    t2 = 256 + t1 - (lg_pmps>>LG_PMPS_SHIFTNO);
    s_flag = 1;
  }

  if (symbol==pred_MPS) //MPS happens
  {	
    s1 = s2;
    t1 = t2;

    //no updating of interval range and low here or
    //renorm to guarantee s1<8, after renorm, s1 --;
    if (s1 == 8) //renorm
    {
      //left shift 1 bit			
      bit_o = (low>>9) &1;


      {			
        bit_oa = (low>>8) &1;

        if (bit_o) 
        {	
          put_one_bit_plus_outstanding( 1);
        }
        else
        {				
          if (!bit_oa)//00
          {						
            put_one_bit_plus_outstanding( 0);
          }
          else {//01
            Ebits_to_follow++;				
            bit_oa = 0;
          }
        }
        s1--;			
      }

      //restore low
      low = ((bit_oa<<8) | (low & 0xff))<<1;		
    }
  }
  else
  {
    is_LPS = 1;

    if (s_flag==0)
      t_rLPS	= (lg_pmps>>LG_PMPS_SHIFTNO);
    else //s2=s1 + 1
      t_rLPS = t1 + (lg_pmps>>LG_PMPS_SHIFTNO);

    low_byte[0] = low + ((t2+256)>>s2); //first low_byte: 10bits
    low_byte[1] = (t2<<(8-s2)) & 0xff;

    //restore range		
    while (t_rLPS<QUARTER){
      t_rLPS = t_rLPS<<1;
      s2 ++;
    }	
    //left shift s2 bits
    {		
      curr_byte = low_byte[0];
      bitstogo = 9;
      bit_oa = (curr_byte>>bitstogo) &0x01;
      byte_no = 0;

      while (s2>0)
      {
        bit_o = bit_oa;
        bitstogo--;
        if (bitstogo<0)
        {
          curr_byte = low_byte[++byte_no];
          bitstogo = 7;
        }
        bit_oa = (curr_byte>>bitstogo) &0x01;
        //				if (AEC_writting==1)
        //					printf("bo:%d/t boa:%d\n",bit_o,bit_oa);

        if (bit_o) 
        {	
          put_one_bit_plus_outstanding( 1);
        }
        else
        {				
          if (1==bit_oa)//01
          {
            Ebits_to_follow++;				
            bit_oa = 0;
          }
          else //00
          {
            put_one_bit_plus_outstanding( 0);
          }

        }
        s2--;			
      }

      //restore low
      low = bit_oa;
      s2 = 9;
      while (s2>0)
      {			
        bitstogo--;
        if (bitstogo<0)
        {
          curr_byte = low_byte[++byte_no];
          bitstogo = 7;
        }
        bit_oa = (curr_byte>>bitstogo) &1;
        low = (low<<1) | bit_oa;
        s2--;
      }
    }


    s1 = 0;
    t1 = t_rLPS & 0xff;		
  }


  if (symbol !=bit1)
  {			
    cycno1 = (cycno1<=2)?(cycno1+1):3;//LPS occurs
  }
  else{
    if (cycno1==0) cycno1 =1;
  }

  if (symbol !=bit2)
  {			
    cycno2 = (cycno2<=2)?(cycno2+1):3;//LPS occurs
  }
  else
  {
    if (cycno2==0) cycno2 =1;
  }
  bi_ct1->cycno = cycno1;
  bi_ct2->cycno = cycno2;
  Elow = low;
  E_s1 = s1;
  E_t1 = t1;
  eep->C++;

  //update probability estimation
  {
    //bi_ct1
    if (symbol==bit1)
    {
      lg_pmps1 = lg_pmps1 - (unsigned int)(lg_pmps1>>cwr1) - (unsigned int)(lg_pmps1>>(cwr1+2));	
    }
    else
    {
      switch(cwr1) {
      case 3:	lg_pmps1 = lg_pmps1 + 197;					
        break;
      case 4: lg_pmps1 = lg_pmps1 + 95;
        break;
      default:lg_pmps1 = lg_pmps1 + 46; 
      }

      if (lg_pmps1>=(256<<LG_PMPS_SHIFTNO))
      {
        lg_pmps1 = (512<<LG_PMPS_SHIFTNO) - 1 - lg_pmps1;
        bi_ct1->MPS = !(bi_ct1->MPS);
      }	
    }
    bi_ct1->LG_PMPS = lg_pmps1;

    //bi_ct2
    if (symbol==bit2)
    {
      lg_pmps2 = lg_pmps2 - (unsigned int)(lg_pmps2>>cwr2) - (unsigned int)(lg_pmps2>>(cwr2+2));	
    }
    else
    {
      switch(cwr2) {
      case 3:	lg_pmps2 = lg_pmps2 + 197;					
        break;
      case 4: lg_pmps2 = lg_pmps2 + 95;
        break;
      default:lg_pmps2 = lg_pmps2 + 46; 
      }

      if (lg_pmps2>=(256<<LG_PMPS_SHIFTNO))
      {
        lg_pmps2 = (512<<LG_PMPS_SHIFTNO) - 1 - lg_pmps2;
        bi_ct2->MPS = !(bi_ct2->MPS);
      }	
    }
    bi_ct2->LG_PMPS = lg_pmps2;
  }


}



void biari_encode_symbol_eq_prob(EncodingEnvironmentPtr eep, unsigned char  symbol)
{
  BiContextType octx;
  BiContextTypePtr ctx=&octx;
  ctx->LG_PMPS = (QUARTER<<LG_PMPS_SHIFTNO)-1;
  ctx->MPS = 0;
  ctx->cycno =0;
  biari_encode_symbol(eep,symbol,ctx); 
}


void biari_encode_symbol_final(EncodingEnvironmentPtr eep, unsigned char symbol)
{
  BiContextType octx;
  BiContextTypePtr ctx=&octx;
  ctx->LG_PMPS = 1<<LG_PMPS_SHIFTNO;
  ctx->MPS = 0;
  ctx->cycno =0;
  biari_encode_symbol(eep,symbol,ctx);
}


/*!
************************************************************************
* \brief
*    Initializes a given context with some pre-defined probability state
************************************************************************
*/


void biari_init_context_logac (BiContextTypePtr ctx)
{
  ctx->LG_PMPS = (QUARTER<<LG_PMPS_SHIFTNO)-1; //10 bits precision
  ctx->MPS	 = 0;
  ctx->cycno   = 0;

}