/***************************************************************************************

***************************************************************************************/


/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/

#include <stdlib.h>
#include <memory.h>
#include <assert.h>
#include "math.h"
#include "global.h"
#include "mbuffer.h"
#include "memalloc.h"
#include <fcntl.h>
#include "io.h"//added by zhang xianguo, Peking University, 201105
/*
*************************************************************************
* Function:Allocate memory for frame buffer
* Input:Input Parameters struct inp_par *inp, Image Parameters struct img_par *img
* Output:
* Return: 
* Attention:
*************************************************************************
*/

//void init_frame_buffers(InputParameters *inp, ImageParameters *img)
//{
//  int i;
//
//  for (i=0;i<2;i++)
//  {
//    get_mem2D(&(mref_frm[i]), (img->height+2*IMG_SUBPIXEL_PAD_SIZE)*4, (img->width+2*IMG_SUBPIXEL_PAD_SIZE)*4);
//  }
//}

