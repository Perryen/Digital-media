#include <memory.h>
#include "defines.h"
#include "global.h"
#include "common.h"

void add_pel_clip(int b8, int b4, int* curr_blk, int bsize, \
				  int (*ppredblk)[16], int (*pm7)[16], int ipix_y, \
				  int iStride, int ipix_x, int ipix_c_y, int ipix_c_x, int iStrideC)
{
	int  x, y;	
	int  by = 8 * (b8 / 2) + 4 * (b4 / 2);
	int  bx = 8 * (b8 % 2) + 4 * (b4 % 2);
	int  curr_val;

	if (b8 < 4){
		for (y = 0; y < bsize; y++) {
			for (x = 0; x < bsize; x++)
			{
				curr_val = ppredblk[bx + x][by + y] + curr_blk[y* bsize + x];
				pm7[x][y] = curr_blk[y* bsize + x] = clamp(curr_val, 0, 255);
				imgY[(ipix_y + by + y)*iStride + ipix_x + bx + x] = (unsigned char)curr_blk[y* bsize + x];
			}
		}
	}
	else{
		for (y = 0; y < bsize; y++) {
			for (x = 0; x < bsize; x++)
			{
				curr_val = ppredblk[x][y] + curr_blk[y* bsize + x];
				pm7[x][y] = curr_blk[y* bsize + x] = clamp(curr_val, 0, 255);

				if ((b8 - 4) % 2)
				{
					imgV[(ipix_c_y + y)*iStrideC+ipix_c_x + x] = (unsigned char)curr_blk[y* bsize + x];
				}
				else
				{
					imgU[(ipix_c_y + y)*iStrideC+ipix_c_x + x] = (unsigned char)curr_blk[y* bsize + x];
				}
			}
		}
	}

	//int  b8_cy = 0;
	//for (y = 0; y < bsize; y++) {
	//	for (x = 0; x < bsize; x++)
	//	{
	//		if (b8 <= 3)
	//		{
	//			curr_val = img->mpr[bx + x][by + y] + curr_blk[y* bsize + x];
	//		}
	//		else
	//		{
	//			//curr_val = img->mpr[x][y + b8_cy] + curr_blk[y* bsize + x];
	//			curr_val = img->mpr[x][y] + curr_blk[y* bsize + x];
	//		}
	//			
	//		img->m7[x][y] = curr_blk[y* bsize + x] = clamp(curr_val, 0, 255);

	//		if (b8 <= 3)
	//		{
	//			imgY[(img->pix_y + by + y)*(img->iStride) + img->pix_x + bx + x] = (unsigned char)curr_blk[y* bsize + x];
	//		}
	//		else
	//		{
	//			if (0 == ((b8 - 4) % 2))
	//			{
	//				//imgU[(img->pix_c_y + b8_cy + y)*(img->iStrideC) + img->pix_c_x + x] = (unsigned char)curr_blk[y* bsize + x];
	//				imgU[(img->pix_c_y + y)*(img->iStrideC) + img->pix_c_x + x] = (unsigned char)curr_blk[y* bsize + x];
	//			}
	//			else
	//			{
	//				//imgV[(img->pix_c_y + b8_cy + y)*(img->iStrideC) + img->pix_c_x + x] = (unsigned char)curr_blk[y* bsize + x];
	//				imgV[(img->pix_c_y + y)*(img->iStrideC) + img->pix_c_x + x] = (unsigned char)curr_blk[y* bsize + x];
	//			}
	//		}
	//	}
	//}
}

/* image padding function */
void padding_rows(pel_t *src, int i_src, int width, int height, int pad)
{
	int i, j;
	pel_t *p;

	// bottom border
	p = src + i_src * (height - 1);
	for (i = 1; i <= pad; i++) {
		memcpy(p + i_src * i, p, width * sizeof(pel_t));
	}

	// above border
	p = src;
	for (i = 1; i <= pad; i++) {
		memcpy(p - i_src * i, p, width * sizeof(pel_t));
	}

	p = src - pad * i_src;

	// left & right
	for (i = 0; i < height + 2 * pad; i++) {
		for (j = 0; j < pad; j++) {
			p[-pad + j] = p[0];
			p[width + j] = p[width - 1];
		}
		p += i_src;
	}
}

void image_padding(ImageParameters *img, uchar_t *rec_y, uchar_t *rec_u, uchar_t *rec_v, int pad)
{
	int padc = pad >> 1;

	g_funs_handle.padding_rows(rec_y, img->iStride, img->width, img->height, pad);
	g_funs_handle.padding_rows(rec_u, img->iStrideC, img->width_cr, img->height_cr, padc);
	g_funs_handle.padding_rows(rec_v, img->iStrideC, img->width_cr, img->height_cr, padc);
}

void com_funs_init_pixel_opt()
{
	//g_funs_handle.com_cpy = com_cpy;
	g_funs_handle.add_pel_clip = add_pel_clip;
	//g_funs_handle.avg_pel = avg_pel;
	g_funs_handle.padding_rows = padding_rows;

#ifdef MT_ENABLE
	g_funs_handle.padding_rows_LR_mt = padding_rows_LR_mt;
#endif // MT_ENABLE

}