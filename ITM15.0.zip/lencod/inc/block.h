/***************************************************************************************

***************************************************************************************/


/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/

#ifndef _IVC_TRANSFORM_H_
#define _IVC_TRANSFORM_H_

#include "global.h"

// external variables
extern const int IVC_COEFF_COST[64];               

// typedefs
typedef enum
{
  PIX,
  LIN
} Direction;

#ifdef RDO_Q
typedef struct level_data_struct
{
	int			level[3];    // candidate levels
	int			levelDouble; // coefficient before quantization
	double      errLevel[3]; // quantization errors of each candidate
	int			noLevels;    // number of candidate levels
	int			pre_level;   // norm quantization level
	double      pre_err;     // quantization errors of norm level
} levelDataStruct;
#endif

// functions
void transform_B8      (int *curr_blk, int bsize);
void inv_transform_B8  (int *curr_blk, int bsize);
void quant_B8          (int qp, int mode, int *curr_blk, int bsize, int Q);
int  scanquant_B8 (int qp, int mode, int b8, int b4, int curr_blk[MB_BLOCK_SIZE*MB_BLOCK_SIZE], int scrFlag, int *cbp, double lambda, int bsize);

int  find_sad_8x8          (int iMode, int iSizeX, int iSizeY, int iOffX, int iOffY, int m7[MB_BLOCK_SIZE][MB_BLOCK_SIZE]);
int  sad_hadamard          (int iSizeX, int iSizeY, int iOffX, int iOffY, int m7[MB_BLOCK_SIZE][MB_BLOCK_SIZE]);
double RDCost_for_IVCIntraBlocks(int *nonzero,int b8, int b4, int ipmode,double lambda,double  min_rdcost, int bsize);

void com_funs_init_forquant();

#endif // _IVC_TRANSFORM_H_
