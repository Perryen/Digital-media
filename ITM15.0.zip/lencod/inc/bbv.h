/***************************************************************************************

***************************************************************************************/

// ===================================================================================
//  File Name:   bbv.h
//  Description: bbv buffer for rate control
// -----------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------
// ===================================================================================

#ifndef  _BBV_H_
#define  _BBV_H_

#include "global.h"

int check_BBS_size(int profile, int level, int* BBS_size);
BbvBuffer_t* init_bbv_memory(InputParameters* pInput);
BbvBuffer_t* free_bbv_memory(BbvBuffer_t* pBbv);
void update_bbv(BbvBuffer_t* pBbv, int code_bits);
void stat_bbv_buffer(BbvBuffer_t* pBbv);
void calc_min_BBS_size(int* FrameBits, int BitRate, float FrameRate, int FrameNum, int *Bmin_out, int *Fmin_out);


#endif //_BBV_H_