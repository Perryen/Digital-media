/***************************************************************************************

***************************************************************************************/


 
/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/
#ifndef GOLOMB_H
#define GOLOMB_H

#include "global.h"

void encode_golomb_word(unsigned int symbol,unsigned int grad0,unsigned int max_levels,unsigned int *res_bits,unsigned int *res_len); //returns symbol coded. (might be cropped if max_levels is too small)
void encode_multilayer_golomb_word(unsigned int symbol,const unsigned int *grad,const unsigned int *max_levels,unsigned int *res_bits,unsigned int *res_len); //terminate using a max_levels value of 30UL.

unsigned int decode_golomb_word(const unsigned char **buffer,unsigned int *bitoff,unsigned int grad0,unsigned int max_levels);

int writeSyntaxElement_GOLOMB(SyntaxElement *se, Bitstream *bitstream);

#endif