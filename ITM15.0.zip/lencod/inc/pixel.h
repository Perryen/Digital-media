#ifndef _PIXEL_H_
#define _PIXEL_H_

#include "global.h"
void add_pel_clip(int b8, int b4, int* curr_blk, int bsize, \
				  int ppredblk[16][16], int(*pm7)[16], int ipix_y, \
				  int iStride, int ipix_x, int b8_cy, int b8_cx, int iStrideC);

void image_padding(ImageParameters *img, uchar_t *rec_y, uchar_t *rec_u, uchar_t *rec_v, int pad);

#endif