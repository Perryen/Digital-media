#ifndef TRANSFORM_H
#define TRANSFORM_H

void inv_transform_B8(int* curr_blk, int bsize);

#endif // !TRANSFORM_H
