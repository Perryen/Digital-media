/***************************************************************************************
This software is developed by Peking University, Tsinghua University and Zhejiang University etc. to be submitted to 
ISO/IEC JTC1/SC29/WG11 for evaluation as test platform of internet video coding. 
* Main Contributors include but are not limited as follows:   
Ronggang Wang, Peking University, Shenzhen Graduate School, rgwang@pkusz.edu.cn,   
Xianguo Zhang,   Peking University
Hao Lv,  Peking University, Shenzhen Graduate School
Zhenyu Wang,  Peking University, Shenzhen Graduate School
Xingguo Zhu,  Zhejiang University
Jianwen Chen,  Tsinghua University
Li Zhang,  Peking University
Siwei Ma,  Peking University
Qin Yu, Peking University
etc.
***************************************************************************************/

#include "global.h"

/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/

#ifndef _LOOP_FILTER_H
#define _LOOP_FILTER_H


//void DeblockFrame(ImageParameters *img, byte *imgY, byte *imgU, byte *imgV);

#endif