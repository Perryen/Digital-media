/***************************************************************************************

***************************************************************************************/



/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/

#ifndef _MV_SEARCH_H_
#define _MV_SEARCH_H_


const int QP2QUANT[40]=
{
   1, 1, 1, 1, 2, 2, 2, 2,
   3, 3, 3, 4, 4, 4, 5, 6,
   6, 7, 8, 9,10,11,13,14,
  16,18,20,23,25,29,32,36,
  40,45,51,57,64,72,81,91
};

int check_mvd(int mvd_x, int mvd_y);
int check_mv_range(int mv_x, int mv_y, int pix_x, int pix_y, int blocktype);
int check_mv_range_bid(int mv_x, int mv_y, int pix_x, int pix_y, int blocktype, int ref);
void SetMotionVectorPredictor (int  pmv[2],int  **refFrArr,int  ***tmp_mv,int  ref_frame,int  mb_pix_x,
                               int  mb_pix_y,int  blockshape_x, int  blockshape_y,int  ref,int  direct_mv);
#endif

