#ifndef INTRA_PREDICTION
#define INTRA_PREDICTION 
#include "global.h"

void intra_pred_luma(uchar_t *pSrc, unsigned char pDst[NO_INTRA_PMODE][256], int uhBlkWidth, bool bAboveAvail, bool bLeftAvail);
void intra_pred_chroma(uchar_t *pSrc_DC, uchar_t *pSrc_NDC, int uv, int block_x, int block_y, bool mb_available_up, bool mb_available_left, bool mb_available_up_left);

#endif