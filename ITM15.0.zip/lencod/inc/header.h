/***************************************************************************************

***************************************************************************************/



/*
*************************************************************************************
* File name: header.h
* Function: Prototypes for header.c
*
*************************************************************************************
*/



#ifndef _HEADER_H_
#define _HEADER_H_
#include "global.h" 
int bbv_check_times;

int slice_vertical_position_extension;
int slice_horizontal_position_extension;   

int stream_length;
int picture_coding_type;
int picture_reference_flag;
int frame_rate;
int tc0;
int marker_bit;

int  SliceHeader(int slice_nr, int slice_qp);
int  IPictureHeader(int frame);
int  PBPictureHeader();
void write_terminating_bit (unsigned char);     
#endif

