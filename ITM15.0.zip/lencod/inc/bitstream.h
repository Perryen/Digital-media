/***************************************************************************************

***************************************************************************************/

/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/

#ifndef _BIT_STREAM_H
#define _BIT_STREAM_H
#include <stdio.h>
#define START_CODE_EMULATION

#ifdef START_CODE_EMULATION

#define STREAM_BUF_SIZE 1024 //must large than 3
typedef struct {
	FILE *f;
	unsigned char	buf[STREAM_BUF_SIZE];
	int	iBytePosition;	
	int	iBitOffset;		
	int	iNumOfStuffBits;	
	int iBitsCount;		
} OutputStream;
int write_start_code(OutputStream *p,unsigned char code);
extern OutputStream *pORABS;
#endif

void CloseBitStreamFile();
void OpenBitStreamFile(char *Filename);
int  WriteSequenceHeader();
int  WriteUserData(char *userdata);
int  WriteSequenceEnd();
int  WriteVideoEditCode();
void WriteBitstreamtoFile();
#endif