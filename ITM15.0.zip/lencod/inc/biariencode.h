/***************************************************************************************

***************************************************************************************/


#ifndef _BIARIENCOD_H_
#define _BIARIENCOD_H_


/************************************************************************
* D e f i n i t i o n s
***********************************************************************
*/
// some definitions to increase the readability of the source code

#define Elow            (eep->Elow)
#define E_s1            (eep->E_s1)
#define E_t1            (eep->E_t1)

#define Ebits_to_follow (eep->Ebits_to_follow)
#define Ebuffer         (eep->Ebuffer)
#define Ebits_to_go     (eep->Ebits_to_go)
#define Ecodestrm       (eep->Ecodestrm)
#define Ecodestrm_len   (eep->Ecodestrm_len)
#define Ecodestrm_laststartcode   (eep->Ecodestrm_laststartcode)


#define B_BITS	10

#define ONE        (1 << B_BITS)
#define HALF       (1 << (B_BITS-1))
#define QUARTER    (1 << (B_BITS-2))

#define LG_PMPS_SHIFTNO 2

#endif  // BIARIENCOD_H

