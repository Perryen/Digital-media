/***************************************************************************************

***************************************************************************************/

#ifndef _AEC_H_
#define _AEC_H_

#include "global.h"

// AEC
void arienco_start_encoding(EncodingEnvironmentPtr eep, byte *code_buffer, int *code_len, /* int *last_startcode, */int slice_type);
int  arienco_bits_written(EncodingEnvironmentPtr eep);
void arienco_done_encoding(EncodingEnvironmentPtr eep);

void biari_init_context_logac (BiContextTypePtr ctx);

void rescale_cum_freq(BiContextTypePtr bi_ct);
void biari_encode_symbol(EncodingEnvironmentPtr eep, unsigned char  symbol, BiContextTypePtr bi_ct );
void biari_encode_symbolW(EncodingEnvironmentPtr eep, unsigned char  symbol, BiContextTypePtr bi_ct1,  BiContextTypePtr bi_ct2);
void biari_encode_symbol_eq_prob(EncodingEnvironmentPtr eep, unsigned char  symbol);
void biari_encode_symbol_final(EncodingEnvironmentPtr eep, unsigned char  symbol);
MotionInfoContexts* create_contexts_MotionInfo(void);
TextureInfoContexts* create_contexts_TextureInfo(void);
void init_contexts_MotionInfo (MotionInfoContexts  *enco_ctx);
void init_contexts_TextureInfo(TextureInfoContexts *enco_ctx);
void delete_contexts_MotionInfo(MotionInfoContexts *enco_ctx);
void delete_contexts_TextureInfo(TextureInfoContexts *enco_ctx);
void writeHeaderToBuffer();
int  writeSyntaxElement_AEC(SyntaxElement *se, DataPartition *this_dataPart);

void writeMBPartTypeInfo_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void write_8x8_PredTypeInfo_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void write_other_PredTypeInfo_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void MHMC_write_16x16_PredTypeInfo_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void MHMC_write_other_PredTypeInfo_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void writeMBTransType_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void writeIntraSplit_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void writeIntraPredMode_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void writeCIPredMode_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void writeMVD_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void writeCBP_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void writeDquant_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void writeRunLevel_AEC_Ref(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void writeWeightedFlag_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void writeBiDirBlkSize_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void print_ctx_TextureInfo(TextureInfoContexts *enco_ctx);
void writeMB_skip_flagInfo_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);
void writeCBP_BIT_AEC (int b8, int b4, int bit, int cbp, Macroblock* currMB, EncodingEnvironmentPtr eep_dp);
void write_significance_map (Macroblock* currMB, EncodingEnvironmentPtr eep_dp, int type, int coeff[], int coeff_ctr);
void writeRunLengthInfo2Buffer_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);

void AEC_new_slice();
void CheckAvailabilityOfNeighborsAEC();

#endif  // AEC_H

extern int DCT_Block_Size;

void write_Reffrm_AEC(SyntaxElement *se, EncodingEnvironmentPtr eep_dp);