/***************************************************************************************

***************************************************************************************/


/*
*************************************************************************************
* File name: 
* Function: 
*
*************************************************************************************
*/
#ifndef _DEFINES_H_
#define _DEFINES_H_

#define GEN_CONFORMANCE_BITSTR 1
#if GEN_CONFORMANCE_BITSTR
#define MULQP        0
#define MULSILICE    0 // == DBLK_E
#define DBLK_ABC     0
#define DBLK_D       0
#define DBLK_F       MULSILICE & DBLK_ABC
#define MVRANGE      0

#endif


#define TRACE          0 //!< 0:Trace off 1:Trace on

#define M38817_DATA_STUFFING 1

#define FastME

// mv prediction
#define MVPRED_xy_MIN   0
#define MVPRED_L        1
#define MVPRED_U        2
#define MVPRED_UR       3

#define BASELINE_PROFILE_ID    0x20

#define HPGOPSIZE 4
#define L1_IMG          1   //sub P frame    
#define L2_IMG          2   //sub P frame		
#define L3_IMG          3   //sub P frame   
#define P_SUB_OPT

#define PSubType_NonAdaptive  // non-adaptive non-reference P frame coding
#define RDO_Q
#define B_DIRECT_REMOVE


#define TOTRUN_NUM    15

#define LUMA_8x8        2
#define CHROMA_DC       6
#define CHROMA_AC       7
#define NUM_BLOCK_TYPES 8

#define MIN(a,b)  (((a)<(b)) ? (a) : (b))  
#define MAX(a,b)  (((a)<(b)) ? (b) : (a))  
#define clamp(a,b,c) ( (a)<(b) ? (b) : ((a)>(c)?(c):(a)) )    //!< clamp a to the range of [b;c]


// ---------------------------------------------------------------------------------
#define _LUMA_COEFF_COST_       4 //!< threshold for luma coeffs

#define IMG_SUBPIXEL_PAD_SIZE    5          //!< Number of sub-pixels padded around the reference frame (>=4)
#define IMG_SUBPIXEL_PAD_SIZE_FOR_CLIP    17          //!< Number of sub-pixels padded around the reference frame (>=4)
#define IMG_PAD_SIZE             (32)   //!< Number of pixels padded around the reference frame (>=4)
//#define IMG_SUBPIXEL_PAD_SIZE    (IMG_SUBPIXEL_EXTRAPAD_SIZE+IMG_PAD_SIZE)

#define absm(A) ((A)<(0) ? (-(A)):(A)) //!< abs macro, faster than procedure
#define MAX_VALUE       999999   //!< used for start value for some variables

#define Clip1(a)            ((a)>255?255:((a)<0?0:(a)))
#define Clip3(min,max,val) (((val)<(min))?(min):(((val)>(max))?(max):(val)))

// ---------------------------------------------------------------------------------

#define B8_SIZE         8       // block size of block transformed by IVC
#define B4_SIZE         4
// ---------------------------------------------------------------------------------

#define P8x8    8
#define I_MB    9
#define IBLOCK  11
#define MAXMODE 13

#define  LAMBDA_ACCURACY_BITS         16
#define  LAMBDA_FACTOR(lambda)        ((int)((double)(1<<LAMBDA_ACCURACY_BITS)*lambda+0.5))
#define  WEIGHTED_COST(factor,bits)   (((factor)*(bits))>>LAMBDA_ACCURACY_BITS)
#define  MV_COST(f,s,cx,cy,px,py)     (WEIGHTED_COST(f,mvbits[((cx)<<(s))-px]+mvbits[((cy)<<(s))-py]))
#define  REF_COST(f,ref)              (WEIGHTED_COST(f,refbits[(ref)]))

#define  BWD_IDX(ref)                 (((ref)<2)? 1-(ref): (ref))

#define IS_INTRA(MB)    ((MB)->mb_type==I_MB)
#define IS_INTER(MB)    ((MB)->mb_type!=I_MB)
#define IS_INTERMV(MB)  ((MB)->mb_type!=I_MB && (MB)->mb_type!=0)
#define IS_DIRECT(MB)   ((MB)->mb_type==0     && (img ->   type==B_IMG))
#define IS_COPY(MB)     ((MB)->mb_type==0     && img ->   type==P_IMG)
#define IS_P8x8(MB)     ((MB)->mb_type==P8x8)

#define MIN_QP          0
#define MAX_QP          63
#define SHIFT_QP        11

// Picture types
#define I_IMG       0   //!< I frame
#define P_IMG       1   //!< P frame
#define B_IMG           2   //!< B frame

// Direct Mode types
#define BLOCK_SIZE      4
#define MB_BLOCK_SIZE   16
#define BLOCK_MULTIPLE      (MB_BLOCK_SIZE/(2*BLOCK_SIZE))

#define NO_INTRA_PMODE  5        //!< #intra prediction modes
//!< 4x4 intra prediction modes
#define VERT_PRED             0
#define HOR_PRED              1
#define DC_PRED               2
#define DOWN_LEFT_PRED   3
#define DOWN_RIGHT_PRED  4

#define TRANS_2Nx2N    0
#define TRANS_NxN      1
#define TRANS_4x4      2

// 8x8 chroma intra prediction modes
#define HOR_PRED_8      1
#define VERT_PRED_8     2
#define PLANE_8         3
#define DC_PRED_8       0

#define EOS             1         //!< End Of Sequence


#define MAX_SYMBOLS_PER_MB  1200  //!< Maximum number of different syntax elements for one MB
                                  // CAVLC needs more symbols per MB

/*!< Maximum size of the string that defines the picture
types to be coded, e.g. "IBBPBBPBB" */
#define MAXPICTURETYPESEQUENCELEN 100   

#define MEMFIX

#define ERROR_BIT


#define ERROR_REF_NUM

#endif

#define INTRA_PB_HYU

//m35892
#define RATECONTROL 
//m35891
#define TDRDO 

// m35746 (2015.02.)
#define FME_BUG_FIXED_HYU

// for 8 bit
#define COMPILE_FOR_8BIT 1

#if COMPILE_FOR_8BIT
#if defined(_WIN32)
#define ENABLE_AVX2 1
#define ENABLE_SSE  1
#define ENABLE_NEON 0
#else
#define ENABLE_AVX2 0
#define ENABLE_SSE  0
#define ENABLE_NEON 1
#endif
#endif

//
typedef signed long long   i64s_t;
typedef signed int         i32s_t;
typedef signed short       i16s_t;
typedef signed char        char_t;
typedef unsigned long long i64u_t;
typedef unsigned int       i32u_t;
typedef unsigned short     i16u_t;
typedef unsigned char      uchar_t;
typedef unsigned char	   bool;