#include "global.h"

#ifndef _TDRDO_H_
#define _TDRDO_H_

#define MAXBLOCKSIZE  16
#define WORKBLOCKSIZE 16
#define SEARCHRANGE   64

typedef struct Block
{
	unsigned int	BlockWidth;
	unsigned int	BlockHeight;
	unsigned int	OriginX;
	unsigned int	OriginY;
	byte			lume[MAXBLOCKSIZE*MAXBLOCKSIZE];	// 4096==64*64
	byte			cr[MAXBLOCKSIZE*MAXBLOCKSIZE/4];	// 1024==4096/4
	byte			cb[MAXBLOCKSIZE*MAXBLOCKSIZE/4];	// 1024==4096/4
}Block;

typedef struct Frame
{
	unsigned int    FrameWidth;
	unsigned int    FrameHeight;
	unsigned int    nStrideY;
	unsigned int    nStrideC;
	byte	* base;
	byte	* Y;
	byte	* U;
	byte	* V;
}Frame;

typedef struct BlockDistortion
{
	unsigned int	GlobalBlockNumber;
	unsigned short	BlockNumInHeight;
	unsigned short	BlockNumInWidth;
	unsigned short	BlockWidth;
	unsigned short	BlockHeight;
	unsigned short	OriginX;
	unsigned short	OriginY;
	unsigned short	SearchRange;
	// 	short			MVx;
	// 	short			MVy;
	double			MSE;
	//	double			MVL;
	short			BlockQP;
	double			BlockLambda;
	short			BlockType;
}BlockDistortion,BD;

typedef struct FrameDistortion
{
	unsigned int	FrameNumber;
	unsigned int	BlockSize;
	unsigned int	CUSize;
	unsigned int	TotalNumOfBlocks;
	unsigned int	TotalBlockNumInHeight;
	unsigned int	TotalBlockNumInWidth;
	BD				*BlockDistortionArray;
}FrameDistortion,FD;

typedef struct DistortionList
{
	unsigned int	TotalFrameNumber;
	unsigned int	FrameWidth;
	unsigned int	FrameHeight;
	unsigned int	BlockSize;
	FD				*FrameDistortionArray;
}DistortionList,DL;

DL * CreatDistortionList(unsigned int totalframenumber, unsigned int w, unsigned int h, unsigned int blocksize, unsigned int cusize);
void DestroyDistortionList(DL * SeqD);
void MotionDistortion(FD *currentFD, Frame * FA, Frame * FB, unsigned int searchrange);
void StoreLCUInf(FD *curRealFD, int LeaderBlockNumber, int cuinwidth, int iqp, double dlambda, int curtype);
void CaculateKappaTableLDP(DL *omcplist, DL *realDlist, int keyframenum, int FrameQP);
void CaculateKappaTableRA(DL *omcplist, DL *realDlist, int framenum, int FrameQP);
void AdjustLcuQPLambdaLDP(FD * curOMCPFD, int LeaderBlockNumber, int cuinwidth, int *pQP, double *plambda);

Frame *porgF,*ppreF,*precF,*prefF;

DL *OMCPDList;
DL *RealDList;
FD *pOMCPFD, *pRealFD,*subpOMCPFD ;

int		StepLength;
double	AvgBlockMSE;
double  *KappaTable;
double  *KappaTable1;
int Gop_size_all;
double  GlobeLambdaRatio;
int		GlobeFrameNumber;
int		CurMBQP;
int		QpOffset[32];
int		GroupSize;
#endif
